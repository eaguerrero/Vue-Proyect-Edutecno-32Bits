<template>
    <div>
        Acá va tu contenido
    </div>
</template>
<script>
import {mapState} from 'vuex'
export default {
}
</script>
